<?php

/**
 * @license LGPLv3, http://opensource.org/licenses/LGPL-3.0
 * @copyright Metaways Infosystems GmbH, 2012
 * @copyright Aimeos (aimeos.org), 2015-2016
 */

return array(
	'common' => array(
		'media' => array(
			'standard' => array(
				'mimeicon' => array(
					'directory' => dirname( __DIR__ ) . '/tmp/media/mimeicons',
				),
			),
		),
	),
);
