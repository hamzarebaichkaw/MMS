<?php

/**
 * @copyright Metaways Infosystems GmbH, 2012
 * @license LGPLv3, http://opensource.org/licenses/LGPL-3.0
 * @copyright Aimeos (aimeos.org), 2015
 */

return array(
	'job' => array(
		'job/unittest job' => array( 'label' => 'unittest job', 'method' => 'controller.method', 'parameter' => array( "items" => "testfile.ext" ), 'result' => array( "items" => "testfile.ext" ), 'status' => 0 )
	)
);