<?php

/**
 * @copyright Metaways Infosystems GmbH, 2012
 * @license LGPLv3, http://opensource.org/licenses/LGPL-3.0
 * @copyright Aimeos (aimeos.org), 2015
 */

return array(
	'log' => array(
		'log/unittest facility' => array( 'facility' => 'unittest facility', 'timestamp' => '2010-01-01 00:00:00', 'priority' => 1, 'message' => 'unittest message', 'request' => 'unittest request' ),
	)
);